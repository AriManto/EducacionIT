﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF
{
    public class Cliente
    {
        private string nombre;
        private int monto;
        public Cliente(string nombreCliente)
        {
            nombre = nombreCliente;
            monto = 0;
        }
        public void Depositar(int montoDeposito)
        {
            monto = monto + montoDeposito;
        }
        public void Extraer(int montoExtraccion)
        {
            monto = monto - montoExtraccion;
        }
        public int RetornarMonto()
        {
            return monto;
        }
        public string Imprimir()
        {
            return nombre.ToUpper() + " tiene depositada la suma de $" + monto + "\r" + "\n";
        }
    }
}
