﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF
{
    class Program
    {
        static void Main(string[] args)
        {
            // P R U E B A S

            // Lab 1
            var unAlumno = new Alumno();
            unAlumno.Apellido = "Montoto";
            unAlumno.Nombre = "Esteban";
            unAlumno.Curso = "POO NET";
            unAlumno.DNI = "30123456";
            unAlumno.Horario = "Ma, Ju Noche";
            unAlumno.Telefono = "1235686959";
            Console.WriteLine("Hemos creado un objeto alumno, sus datos son: ");
            Console.WriteLine("Nombre y Apellido: {0} {1}", unAlumno.Nombre, unAlumno.Apellido);
            Console.WriteLine("Se anotó en el curso {0} en el horario {1}", unAlumno.Curso, unAlumno.Horario);
            Console.WriteLine("Su DNI y teléfono son {0} y {1}", unAlumno.DNI, unAlumno.Telefono);
            Console.WriteLine("");
            Console.ReadKey();

            // Lab 2
            var miBanco = new Banco();
            miBanco.Operar();
            Console.WriteLine(miBanco.DepositosTotales());
            Console.ReadKey();

            // Lab 3
            //Se utiliza el constructor para pasar parametros iniciales   
            var alumno1 = new Lab3.Alumno(unAlumno.Nombre, "25");
            Console.WriteLine(alumno1.Imprimir());
            Console.WriteLine(alumno1.EsMayorEdad());
            Console.ReadKey();


        }
    }
}
