﻿namespace SF
{
    public enum DiasDeLaSemana
    {
        Lunes,
        Martes,
        Miercoles,
        Jueves,
        Viernes,
        Sabado,
        Domingo,
        Osvaldo
    }
}