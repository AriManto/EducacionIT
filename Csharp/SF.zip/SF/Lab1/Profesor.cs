﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF
{
    public class Profesor:Persona
    {
        public DiasDeLaSemana Dia { get; set; }
        public string Horario { get; set; }
    }
}
